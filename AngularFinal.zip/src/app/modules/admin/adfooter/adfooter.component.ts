import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adfooter',
  templateUrl: './adfooter.component.html',
  styleUrls: ['./adfooter.component.css']
})
export class AdfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
