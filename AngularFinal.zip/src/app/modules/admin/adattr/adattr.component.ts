import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adattr',
  templateUrl: './adattr.component.html',
  styleUrls: ['./adattr.component.css']
})
export class AdattrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
